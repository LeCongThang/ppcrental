<?php $__env->startSection('content'); ?>
    <div class="intro-header">


        <!--<h1>Landing Page</h1>-->
        <!--<h3>A Template by Start Bootstrap</h3>-->
        <!--<hr class="intro-divider">-->
        <!--<ul class="list-inline intro-social-buttons">-->
        <!--<li>-->
        <!--<a href="https://twitter.com/SBootstrap" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="https://github.com/IronSummitMedia/startbootstrap" class="btn btn-default btn-lg"><i class="fa fa-github fa-fw"></i> <span class="network-name">Github</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>-->
        <!--</li>-->
        <!--</ul>-->
        <div class="home-below-menu"
             style="background: url('<?php echo e(URL::asset('images/common_icon/title-bg.jpg')); ?>') no-repeat center center;background-size: cover;">
            <h2>RESULT</h2>
        </div>


        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('partial.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-custom">
                        <div class="panel-body panel-body-custom">
                            <div class="col-lg-10">
                                <p><?php echo e($items->count()); ?> Properties found</p>

                            </div>
                            
                                
                                    
                                
                            
                            <?php if($items->count()>0): ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-lg-4">
                                    <a href="<?php echo e(URL::asset('')); ?>property/<?php echo e($i->id); ?>-<?php echo e($i->slug); ?>.html" ><img src="<?php echo e(URL::asset('')); ?>images/project/<?php echo e($i->image_overall); ?>"
                                         class="img-responsive"></a>
                                    <h4><a href="<?php echo e(URL::asset('')); ?>property/<?php echo e($i->id); ?>-<?php echo e($i->slug); ?>.html" ><?php echo e($i->name_en); ?></a></h4>
                                    <i style="font-weight:normal"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(str_limit($i->location,45)); ?></i>
                                    <p><?php echo str_limit($i->description_en,300); ?></p>
                                    <hr/>
                                    <p><span class="glyphicon glyphicon-home"> <?php echo e($i->area); ?></span> &nbsp; &nbsp;&nbsp;
                                        <span
                                                class="glyphicon glyphicon-bed"> <?php echo e($i->bedroom); ?> Bedrooms</span></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
                                <div class="col-lg-12"></div>
                            <h3 class="text-center text-danger">Opp! No property found</h3>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>