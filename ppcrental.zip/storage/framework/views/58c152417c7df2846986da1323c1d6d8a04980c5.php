<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="dashboard_graph">

                <div class="row x_title">
                    <div class="col-md-6">
                        <h3>About management
                            
                        </h3>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="col-md-12">
                    <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form id="demo-form2" data-parsley-validate action="<?php echo e(URL::asset('')); ?>admin/about-management"
                              method="post" class="form-horizontal form-label-left">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <h5 class="text-center">Vietnamese contents</h5>
                            <div class="col-lg-12">
                            <textarea name="intro" class="form-control" required rows="20">
                                <?php echo e($i->intro); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                                <textarea name="about" class="form-control" required rows="10">
                                <?php echo e($i->about); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                               <textarea name="ourteam" class="form-control" required rows="10">
                                <?php echo e($i->ourteam); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                                <textarea name="ceo" class="form-control" required rows="10">
                                <?php echo e($i->ceo); ?>

                            </textarea>
                            </div>
                            <h5 class="text-center">English contents</h5>
                            <div class="col-lg-12">
                            <textarea name="intro_en" class="form-control" required rows="20">
                                <?php echo e($i->intro_en); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                                <textarea name="about_en" class="form-control" required rows="10">
                                <?php echo e($i->about_en); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                               <textarea name="ourteam_en" class="form-control" required rows="10">
                                <?php echo e($i->ourteam_en); ?>

                            </textarea>
                            </div>
                            <div class="col-lg-4">
                                <textarea name="ceo_en" class="form-control" required rows="10">
                                <?php echo e($i->ceo_en); ?>

                            </textarea>
                            </div>


                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button class="btn btn-primary" type="button">Cancel</button>
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>


                        </form>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(URL::asset('')); ?>ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('intro', {
            filebrowserBrowseUrl: '<?php echo e(URL::asset('')); ?>ckfinder/ckfinder.html',
            filebrowserImageBrowseUrl: '<?php echo e(URL::asset('')); ?>ckfinder/ckfinder.html?type=About',
            filebrowserUploadUrl: '<?php echo e(URL::asset('')); ?>ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
            filebrowserImageUploadUrl: '<?php echo e(URL::asset('')); ?>ckfinder/core/connector/php/connector.php?command=QuickUpload&type=About'
        });
        CKEDITOR.replace('about');
        CKEDITOR.replace('ourteam');
        CKEDITOR.replace('ceo');
        CKEDITOR.replace('intro_en', {
            filebrowserBrowseUrl: '<?php echo e(URL::asset('')); ?>ckfinder/ckfinder.html',
            filebrowserImageBrowseUrl: '<?php echo e(URL::asset('')); ?>ckfinder/ckfinder.html?type=About',
            filebrowserUploadUrl: '<?php echo e(URL::asset('')); ?>ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
            filebrowserImageUploadUrl: '<?php echo e(URL::asset('')); ?>ckfinder/core/connector/php/connector.php?command=QuickUpload&type=About'
        });
        CKEDITOR.replace('about_en');
        CKEDITOR.replace('ourteam_en');
        CKEDITOR.replace('ceo_en');
    </script>
    <style>
        .table tbody tr td input {
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>