<?php $__env->startSection('content'); ?>
    <div class="intro-header">


        <!--<h1>Landing Page</h1>-->
        <!--<h3>A Template by Start Bootstrap</h3>-->
        <!--<hr class="intro-divider">-->
        <!--<ul class="list-inline intro-social-buttons">-->
        <!--<li>-->
        <!--<a href="https://twitter.com/SBootstrap" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="https://github.com/IronSummitMedia/startbootstrap" class="btn btn-default btn-lg"><i class="fa fa-github fa-fw"></i> <span class="network-name">Github</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>-->
        <!--</li>-->
        <!--</ul>-->
        <div class="home-below-menu">
            <h2>ABOUT US</h2>
        </div>


        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-custom">
                        <div class="panel-body panel-body-custom">
                            <h3>Welcome!</h3>
                            <p>Perfect Property Company (PPC) is known as a professional enterprise operating in the
                                field of real estate brokerage and marketing both domestically and internationally. PPC
                                focuses on two main areas:
                                - Real estate - Tourist Resorts PPC is the most trusted and satisfied option for all
                                customers. PPC is found and </p>
                            <img src="<?php echo e(URL::asset('')); ?>images/homepage/banner.jpg" class="img-responsive">
                            <div class="col-lg-4">
                                <h3>About us</h3>
                                <p>Perfect Property Company (PPC) is known as a professional enterprise operating
                                    in the field of real estate brokerage and marketing both domestically and internationally. PPC focuses on two main
                                    areas: - Real estate - Tourist Resorts PPC is the most trusted and satisfied option for all customers. PPC is found and </p>
                            </div>
                            <div class="col-lg-4">
                                <h3>Our team</h3>
                                <p>Perfect Property Company (PPC) is known as a professional enterprise operating
                                    in the field of real estate brokerage and marketing both domestically and internationally. PPC focuses on two main
                                    areas: - Real estate - Tourist Resorts PPC is the most trusted and satisfied option for all customers. PPC is found and </p>
                            </div>
                            <div class="col-lg-4">
                                <h3>CEO</h3>
                                <p>Perfect Property Company (PPC) is known as a professional enterprise operating
                                    in the field of real estate brokerage and marketing both domestically and internationally. PPC focuses on two main
                                    areas: - Real estate - Tourist Resorts PPC is the most trusted and satisfied option for all customers. PPC is found and </p>
                            </div>
                            <hr/>
                            hadbjsd
                            <hr/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>