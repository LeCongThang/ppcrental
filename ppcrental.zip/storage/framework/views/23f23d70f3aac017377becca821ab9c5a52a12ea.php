<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <a href="<?php echo e(URL::asset('')); ?>admin/create-user" class="btn btn-md btn-success">Add news</a>
            <div class="dashboard_graph">

                <div class="row x_title">
                    <div class="col-md-6">
                        <h3>User management
                            
                        </h3>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>No.</th>
                            <th>Avatar</th>
                            <th>Email</th>
                            <th>Full name</th>
                            <th>Create at</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td width="100"><img src="<?php echo e(URL::asset('')); ?>images/users/<?php echo e($item->avatar); ?>" width="50%"/></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->fullname); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td><?php if($item->status==0): ?>
                                        <label class="text-danger"><i class="fa fa-circle-o"></i></label>
                                    <?php else: ?>
                                        <label class="text-success"><i class="fa fa-check-circle"></i></label>
                                    <?php endif; ?>
                                </td>


                                <td>
                                    <a href="<?php echo e(URL::asset('')); ?>admin/edit-user-<?php echo e($item->id); ?>" class="btn btn-xs btn-primary">Edit</a>
                                    <a href="<?php echo e(URL::asset('')); ?>admin/reset-password-user-<?php echo e($item->id); ?>" class="btn btn-xs btn-primary">Reset password</a>
                                    <?php if($loop->count<=2): ?>
                                        <i>Default 3 user, can't delete</i>
                                    <?php else: ?>
                                        <a href="<?php echo e(URL::asset('')); ?>admin/delete-user-<?php echo e($item->id); ?>" class="btn btn-xs btn-danger deletelink">Delete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot></tfoot>
                    </table>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.deletelink').click(function (e) {
            var a_href = $(this).attr('href');
            /* Lấy giá trị của thuộc tính href */
            e.preventDefault();
            /* Không thực hiện action mặc định */
            $.ajax({
                /* Gửi request lên server */
                url: a_href, /* Nội dung trong Delete.cshtml cụ thể là deleteModal div được server trả về */
                type: 'GET',
                contentType: 'application/json; charset=utf-8',
                success: function (data) { /* Sau khi nhận được giá */
                    $('.body-content').prepend(data);
                    /* body-content div (định nghĩa trong _Layout.cshtml) sẽ thêm deleteModal div vào dưới cùng */
                    $('#deleteModal').modal('show');
                    /* Hiển thị deleteModal div dưới kiểu modal */
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>