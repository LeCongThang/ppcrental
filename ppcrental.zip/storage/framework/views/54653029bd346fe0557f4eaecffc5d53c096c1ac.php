<?php $__env->startSection('content'); ?>
    <div id="fb-root"></div>
    <script>(function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    <div class="intro-header">


        <!--<h1>Landing Page</h1>-->
        <!--<h3>A Template by Start Bootstrap</h3>-->
        <!--<hr class="intro-divider">-->
        <!--<ul class="list-inline intro-social-buttons">-->
        <!--<li>-->
        <!--<a href="https://twitter.com/SBootstrap" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="https://github.com/IronSummitMedia/startbootstrap" class="btn btn-default btn-lg"><i class="fa fa-github fa-fw"></i> <span class="network-name">Github</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>-->
        <!--</li>-->
        <!--</ul>-->
        <div class="home-below-menu"
             style="background: url('<?php echo e(URL::asset('images/common_icon/title-bg.jpg')); ?>') no-repeat center center;background-size: cover;">
            <h2><?php echo e($p->name_en); ?></h2>
        </div>


        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="panel panel-custom">
                        <div class="panel-body panel-body-custom">
                            <h3><?php echo e($p->name_en); ?> &nbsp; <span>
                                        <button type="submit" class=" favorite btn search-form"><span
                                                    class="glyphicon glyphicon-heart"></span> Add to favorite</button>
                                                               </span>
                            </h3>
                            <h4 style="font-weight:normal;color: #00aeef">Price: <?php echo e($p->price); ?></h4>
                            <img src="<?php echo e(URL::asset('')); ?>images/project/propertyfull-<?php echo e($p->id); ?>.jpg"
                                 class="img-responsive">
                            <hr/>
                            <h3>Project description:</h3>
                            <p><?php echo $p->description_en; ?></p>
                            <hr/>
                            <h3>Quick summary:</h3>
                            <p>Property status: <?php if($p->property_status=1): ?> For Rent <?php else: ?> For Sale <?php endif; ?></p>
                            <p>Property type: <?php echo e(\App\Models\PpcPropertyCategory::find($p->property_type)->name_en); ?></p>
                            <p>Location: <?php echo e($p->location); ?></p>
                            <p>Bedrooms: <span class="glyphicon glyphicon-bed"></span> <?php echo e($p->bedroom); ?> </p>
                            <p>Bathrooms: <?php echo e($p->bathroom); ?></p>
                            <p>Area: <span class="glyphicon glyphicon-home"></span> <?php echo e($p->area); ?></p>
                            <p>Parking place: <?php echo e($p->parkingplace); ?></p>
                            <p>Property faeture: <?php $__currentLoopData = $feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($i->feature_en.', '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                            <hr/>
                            <h3>Contact:</h3>
                            <div class="col-lg-3">
                                <img src="<?php echo e(URL::asset('')); ?>images/users/<?php echo e($user->avatar); ?>" class="img-responsive">
                            </div>
                            <div class="col-lg-9">
                                <h4><?php echo e($user->fullname); ?></h4>
                                <p><span class="glyphicon glyphicon-phone"></span> Mobile: <?php echo e($user->phone); ?></p>
                                <p><span class="glyphicon glyphicon-envelope"></span> Email: <?php echo e($user->email); ?></p>
                                <p><span class="glyphicon glyphicon-phone"></span> Office: <?php echo e($user->office_phone); ?></p>
                                <p><span class="glyphicon glyphicon-map-marker"></span> <?php echo e($user->address_en); ?></p>
                            </div>
                            <hr/>

                            <a class="btn search-form" href="#"
                               onclick="share_fb('<?php echo e(URL::asset('')); ?>/news/<?php echo e($p->id); ?>-<?php echo e($p->slug_en); ?>.html');return false;"
                               rel="nofollow"
                               share_url="<?php echo e(URL::asset('')); ?>/property/<?php echo e($p->id); ?>-<?php echo e($p->slug_en); ?>.html" target="_blank">
                                <i class="fa fa-facebook" aria-hidden="true"></i> Share
                            </a>

                        </div>
                    </div>
                </div>

                    <?php echo $__env->make('partial.searchright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function share_fb(url) {
            window.open('https://www.facebook.com/sharer/sharer.php?u=' + url, 'facebook-share-dialog', "width=626,height=436")
        }
        $('.favorite').click(function (e) {

            /* Lấy giá trị của thuộc tính href */
            e.preventDefault();
            /* Không thực hiện action mặc định */
            $.ajax({
                /* Gửi request lên server */
                url: '<?php echo e(URL::asset('')); ?>add-favorite-<?php echo e($p->id); ?>',
                type: 'get',
                contentType: 'application/json; charset=utf-8',
                success: function (data) { /* Sau khi nhận được giá */
                    alert(data);
                }
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>