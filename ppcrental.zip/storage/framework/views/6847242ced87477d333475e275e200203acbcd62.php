<?php $__env->startSection('content'); ?>
    <div id="fb-root"></div>
    <script>(function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
    <div class="intro-header">


        <!--<h1>Landing Page</h1>-->
        <!--<h3>A Template by Start Bootstrap</h3>-->
        <!--<hr class="intro-divider">-->
        <!--<ul class="list-inline intro-social-buttons">-->
        <!--<li>-->
        <!--<a href="https://twitter.com/SBootstrap" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="https://github.com/IronSummitMedia/startbootstrap" class="btn btn-default btn-lg"><i class="fa fa-github fa-fw"></i> <span class="network-name">Github</span></a>-->
        <!--</li>-->
        <!--<li>-->
        <!--<a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i> <span class="network-name">Linkedin</span></a>-->
        <!--</li>-->
        <!--</ul>-->
        <div class="home-below-menu">
            <h2>NEWS</h2>
        </div>


        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

    <div class="content-section-a">

        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="panel panel-custom">
                        <div class="panel-body panel-body-custom">
                            <h3><?php echo e($news->title_en); ?></h3>
                            <i style="font-weight:normal"><?php echo e($news->updated_at); ?></i>
                            <img src="<?php echo e(URL::asset('')); ?>images/news/<?php echo e($news->image); ?>" class="img-responsive">
                            <?php echo $news->content_en; ?>

                            <a class="btn search-form" href="#" onclick="share_fb('<?php echo e(URL::asset('')); ?>/news/<?php echo e($news->id); ?>-<?php echo e($news->slug_en); ?>.html');return false;" rel="nofollow"
                               share_url="<?php echo e(URL::asset('')); ?>/news/<?php echo e($news->id); ?>-<?php echo e($news->slug_en); ?>.html" target="_blank">
                                <i class="fa fa-facebook" aria-hidden="true"></i> Share
                            </a>

                        </div>
                    </div>
                </div>

                    <?php echo $__env->make('partial.searchright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function share_fb(url) {
            window.open('https://www.facebook.com/sharer/sharer.php?u='+url,'facebook-share-dialog',"width=626,height=436")
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>