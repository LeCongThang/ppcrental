<div class="modal fade" id="editModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header modal-custom">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Edit position</h4>
            </div>
            <form action="<?php echo e(URL::asset('')); ?>admin/edit-position-<?php echo e($district->id); ?>" method="post"
                  class="form-horizontal">
                <div class="modal-body">

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label class="control-label col-lg-2">District:</label>
                        <div class="col-lg-10">
                            <select name="district" id="district" class="form-control selectpicker"
                                    data-live-search="true"
                                    title="--Choose--"
                                    onchange="loaddistrict();" required>
                                <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                            <?php if($item->id==$district->id): ?> selected <?php endif; ?>
                                    ><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-2">Name(en):</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="text" id="name_en" name="name_en" placeholder="Name (en)"
                                   value="<?php echo e($district->name_en); ?>" required/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-2">Description:</label>
                        <div class="col-lg-10">
                            <textarea class="form-control" rows="4" id="description" name="description"
                                      required><?php echo e($district->description); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-2">Description(en):</label>
                        <div class="col-lg-10">
                            <textarea class="form-control" rows="4" id="description_en" name="description_en"
                                      required><?php echo e($district->description_en); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-lg-2">Change image:</label>
                        <div class="col-lg-10">
                            <input class="form-control" type="file" name="image" id="image" required
                                   onchange="loadFile(event)"/>
                            <img id="output" src="<?php echo e(URL::asset('')); ?>images/homepage/<?php echo e($district->image); ?>" width="30%"/>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <input type="submit" value="Update" class=" btn search-form"/>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('.selectpicker').selectpicker();
    function loaddistrict() {
        var id = $('#district').val();
        $.ajax({
            type: "GET",
            url: "<?php echo e(URL::asset('')); ?>admin/district-detail-" + id,

            success: function (data) {
                if (data != null) {
                        $('#name_en').val(data.name_en);
                        $('#description').val(data.description);
                        $('#description_en').val(data.description_en);
                        $('#output').attr('src', '<?php echo e(URL::asset('')); ?>images/homepage/' + data.image);
                    }
                }

        })
    }
</script>


